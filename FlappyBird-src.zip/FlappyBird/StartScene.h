#pragma once
#include <easy2d.h>

class StartScene :
	public EScene
{
public:
	StartScene();
	void onEnter() override;
};

