#pragma once
#include "easy2d.h"

class Ground :
	public ESprite
{
public:
	Ground();
	~Ground();

	void stop();
};

